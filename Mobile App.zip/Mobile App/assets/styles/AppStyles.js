import { StyleSheet } from 'react-native';

export default Styles = StyleSheet.create({
    // Big container
	container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    }
});
